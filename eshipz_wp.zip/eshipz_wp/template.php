<?php

ob_start();

if(isset($_POST['labelstatus']) && isset($_POST['orderid']) && isset($_POST['bookingstatus']))
{
    $ls = $_POST['labelstatus'];
    $od = $_POST['orderid'];
    $bs = $_POST['bookingstatus'];
    update_post_meta( $od, 'label_status', $ls );
    update_post_meta( $od, 'booking_status', $bs );
    exit;
}
if(isset($_POST['eczid']) && isset($_POST['orderid']) && isset($_POST['trackid']))
{
    $id = $_POST['eczid'];
    $od1 = $_POST['orderid'];
    $td = $_POST['trackid'];
    update_post_meta( $od1, 'ecz_id', $id);
    update_post_meta( $od1, 'tracking_no', $td);
    exit;
}
if(isset($_POST['labellink']) && isset($_POST['orderid']))
{
    $lbl = $_POST['labellink'];
    $od2 = $_POST['orderid'];
    update_post_meta( $od2, 'label_link', $lbl);
    update_post_meta( $od2, 'label_status', 1);
    exit;
}

if(isset($_POST['trackid']) && isset($_POST['orderid']))
{
    $tid = $_POST['trackid'];
    $od3 = $_POST['orderid'];
    update_post_meta( $od3, 'tracking_no', $tid);
    exit;
}
if(isset($_POST['package_awb']) && isset($_POST['orderid']))
{
    $awb = $_POST['package_awb'];
    $od8 = $_POST['orderid'];
    update_post_meta( $od8, 'subpackage_awb', $awb);
    exit;
}
if(isset($_POST['cod_label']) && isset($_POST['orderid']))
{
    $cod = $_POST['cod_label'];
    $od9 = $_POST['orderid'];
    update_post_meta( $od9, 'cod_label', $cod);
    exit;
}
if(isset($_POST['subpackages_label']) && isset($_POST['orderid']))
{
    $sbp = $_POST['subpackages_label'];
    $od10 = $_POST['orderid'];
    update_post_meta( $od10, 'subpackages_label', $sbp);
    exit;
}
?>
<html>

<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">

    <style>
        .big-text {
            font-size: 10px;
        }

        .p {
            font-size: 10px;
        }

        .text-center {
            font-size: 10px;
        }
        .text-center {
            font-size: 10px;
        }
        @media (min-width: 1199px)
            .quote-result-column-header {
                padding: 8px 10px;
                font-weight: 700;
            }
            .quote-result-column-header {
                background-color: #5A5A5A;
                border: 1px solid #444;
                color: #fff;
                position: relative;
                clear: both;
                margin-bottom: 7.5px;
                font-weight: 400;
                padding: 8px 5px;
            }
            .hidden-xs {
                display: block!important;
            }
            .text-center {
                text-align: center;
            }
            .glow {
                display: block;
                -webkit-transition-duration: .5s;
                transition-duration: .5s;
                -webkit-transition-property: box-shadow;
                transition-property: box-shadow;
                -webkit-transform: translateZ(0);
                transform: translateZ(0);
                box-shadow: 0 0 1px rgba(0,0,0,0);
            }
            .panel {
                margin-bottom: 10px;
            }
            .panel-success {
                border-color: #d6e9c6;
            }
            .panel {
                background-color: #fff;
                border: 1px solid transparent;
                border-radius: 4px;
                -webkit-box-shadow: 0 1px 1px rgba(0,0,0,.05);
                -moz-box-shadow: 0 1px 1px rgba(0,0,0,.05);
                box-shadow: 0 1px 1px rgba(0,0,0,.05);
            }
            *, :after, :before {
                -webkit-box-sizing: border-box;
                -moz-box-sizing: border-box;
                box-sizing: border-box;
            }
            body {
                color: #5a5a5a;
                text-shadow: -1px 0 1px rgba(0,0,0,.1);
            }
            .panel-spacing-red {
                padding: 0!important;
            }
            .panel-body:after, .panel-body:before {
                content: " ";
                display: table;
            }
            .panel-body:after {
                clear: both;
            }
            .result-top-row {
                padding: 10px 0 0;
            }
            @media (min-width: 992px)
                .col-md-12 {
                    width: 100%;
                }

                img {
                    vertical-align: middle;
                }
                .item_price {
                    position: relative;
                    right: 10px;
                }

                .no-padding {
                    padding: 0!important;
                }
                @media (min-width: 900px)
                    .col-md-4 {
                        width: 33.33333333333333%;
                    }
                    .text-right {
                        text-align: right;
                    }
                    .result-service-name {
                        text-align: center;
                        font-size: 16px;
                        color: #e64a19;
                        text-transform: uppercase;
                    }
                    .result-service-name .service-name {
                        text-transform: uppercase;
                        color: #000;
                    }
                    .no_top_hr {
                        margin-top: 5px;
                        margin-bottom: 5px;
                        border-top: 1px solid rgba(255,255,255,.8);
                        border-bottom: 1px solid rgba(0,0,0,.2);
                    }
                    .feature-box p {
                        margin: 0;
                    }
                    .panel-footer {
                        padding: 10px 15px;
                        background-color: #f5f5f5;
                        border-top: 1px solid #ddd;
                        border-bottom-right-radius: 3px;
                        border-bottom-left-radius: 3px;
                    }
                    .btn3d.btn-danger {
                        box-shadow: 0 0 0 1px #b93802 inset,0 0 0 2px rgba(255,255,255,.15) inset,0 8px 0 0 #a00,0 8px 8px 1px rgba(0,0,0,.5);
                        background-color: #D73814;
                    }
                    .vendor-button {
                        padding-top: 5px;
                        padding-bottom: 5px;
                        font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
                        font-size: 18!important;
                    }
                    .btn3d, .btn3d:focus {
                        position: relative;
                        top: -6px;
                        border: 0;
                        -moz-outline-style: none;
                        outline: medium none;
                        transition: all .04s linear;
                        margin-top: 10px;
                        margin-bottom: 10px;
                        margin-left: 2px;
                        margin-right: 2px;
                    }
                    .btn-block {
                        display: block;
                        width: 100%;
                        padding-left: 0;
                        padding-right: 0;
                    }
                    .btn-danger {
                        color: #fff;
                        background-color: #d9534f;
                        border-color: #d43f3a;
                    }
                    .btn {
                        display: inline-block;
                        margin-bottom: 0;
                        font-weight: 400;
                        text-align: center;
                        vertical-align: middle;
                        cursor: pointer;
                        background-image: none;
                        border: 1px solid transparent;
                        white-space: nowrap;
                        padding: 6px 12px;
                        font-size: 14px;
                        line-height: 1.428571429;
                        border-radius: 4px;
                        -webkit-user-select: none;
                        -moz-user-select: none;
                        -ms-user-select: none;
                        -o-user-select: none;
                        user-select: none;
                    }

    </style>
    <style>
    div.addcheck {
    display:inline-block;  
    vertical-align:top;
    text-align:center;
    width:auto;
    margin:0 47px 0 0;
    padding:24px 22px 20px 27px;
    border:1px solid transparent;
}

div.addcheck:last-child {
    margin:0px;
}

div.addcheck:hover {
    border:1px solid #878787;
    -moz-border-radius:3px;
    border-radius:3px;
}

div.addcheck.unselected {
    opacity:0.6;
    filter:alpha(opacity=60);
}

div.addcheck.selected {
    border:1px solid #32a24e;
    -moz-border-radius:3px;
    border-radius:3px;
}

    </style>
</head>
<div>

</div>

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content" style="width:140%;
    margin-left:-20%;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <center>
                    <h2 class="modal-title">eCourierz</h2></center>
                <span id='loading' style='color:#e24848;font-size: 22px;'>Loading...</span>
            </div>
            <div class="modal-body">
                <div id="selectadd" class="hidden">
                <div id="showadd"></div>
                <button id="goto">Next</button>
                </div>
                <div id="newone" style="height:auto; background-color: #eee;padding: 2%;">
                    <div id="newtwo">
                    

                    </div>
                    <div id='iscod' class='hidden'>
                        <div class='row' id='stp'>
                            <div class='col-md-6'><span style='margin-left: 39%;font-weight: bold;font-size: 19px;'>Select Shipment Type :</span></div>
                            <div class='col-md-6'>
                                <select id='stype' style='background-color: #d9534f;outline: none;border: none;color: white;'>
<!--                                    <option>Select Order's Payment Type</option>-->
                                    <option value="false" id="prepaid">PREPAID</option>
                                    <option value="true" id="cod">COD</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <h3 class="hds">Select Pickup Address</h3>

                    <div id = "warehouses">

                    </div>



                    <br>
                    <button type="button" id="" class="btn btn-danger btn-lg proceed0" disabled data-dismiss="" style="margin-left: 44%;">Proceed</button>
                    
                    <button type="button" id="" class="btn btn-danger btn-lg hidden proceed1" data-dismiss="" style="margin-left: 44%;">Proceed</button>

                </div>
                <div id="getset" style="background-color: #f1f1f1;">
                    <div class="row">

                        <div class="col-sm-12">
                            <div id="days-tab">
                                <div class="col-sm-4">
                                    <div class="quote-result-column-header hidden-xs text-center " rel="tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="">
                                        1 - 2 Days Transit <sup></sup>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="quote-result-column-header hidden-xs text-center" rel="tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="">
                                        2 - 3 Days Transit <sup></sup>
                                    </div>
                                </div>

                                <div class=" col-sm-4">
                                    <div class="quote-result-column-header hidden-xs text-center" rel="tooltip" data-toggle="tooltip" data-placement="top" title="" data-original-title="">
                                        3+ Days Transit <sup></sup>
                                    </div>
                                </div>
                            </div>
                            <div id="vendor-boxes">
                                <!-- <div class="table-responsive" id="rates_listing_table">  -->
                                <div class="hidden" id="msg"><center><h2>No services available!!!</h2></center></div>
                                <div class="col-sm-4" id="n1"></div>
                                <div class="col-sm-4" id="n2"></div>
                                <div class="col-sm-4" id="n3"></div>
                            </div>
                    
                        </div>
                        
                    </div>
                </div>

                <div id="next" class="hidden" style="padding: 2%;">
                    <div class="row" style="background-color: #f1f1f1;
    padding: 2%;">
                        <span id="product_id" class="hidden" value=""></span>
                        <span id="parcel_content" class="hidden" value=""></span>
                        <span id="fname" class="hidden" value=""></span>
                        <span id="lname" class="hidden" value=""></span>
                        <span id="receiver_company" class="hidden" value=""></span>
                        <span id="receiver_shipadd1" class="hidden" value=""></span>
                        <span id="receiver_shipadd2" class="hidden" value=""></span>
                        <span id="receiver_city" class="hidden" value=""></span>
                        <span id="receiver_state" class="hidden" value=""></span>
                        <span id="receiver_country" class="hidden" value=""></span>
                        <span id="delivery_pincode" class="hidden" value=""></span>
                        <span id="count" class="hidden" value=""></span>
                        <span id="pickup_pincode" class="hidden" value=""></span>
                        <span id="is_cod" class="hidden" value="false"></span>
                        <span id="fixed_address" class="hidden" value=""></span>
                        <span id="sender_company_name" class="hidden" value=""></span>
                        <span id="sender_street1" class="hidden" value=""></span>
                        <span id="sender_street2" class="hidden" value=""></span>
                        <span id="sender_primary_contact" class="hidden" value=""></span>
                        <span id="sender_primary_phone" class="hidden" value=""></span>
                        <span id="sender_primary_email" class="hidden" value=""></span>
                        <span id="sender_primary_city" class="hidden" value=""></span>
                        <span id="site_name" class="hidden" value=""></span>
                        <span id ="count" class="hidden" value=""></span>
                        <span id ="oid" class="hidden" value=""></span>
                        <span id ="data" class="hidden" value=""></span>
                         <span id ="content" class="hidden" value=""></span>
                        <h1>Sender Details</h1>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Sender Name</label><br>
                                <span id="sender_name"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Mobile No</label><br>
                                <span id="sender_contact"></span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="">Email id</label><br>
                                <span id="sender_email"></span>
                            </div>
                        </div>
                        <div class="input-group" style="margin-left:2%;">
                            <label for="">Sender Address</label>
                            <span id="sender_address"></span>
                        </div>
                    </div>
                    
                    <div class="row" style="background-color: #f1f1f1;
    padding: 2%;">
                        <h1>Receiver Details</h1>
                        <div class="row">
                            <div class="col-md-4">

                                <label for="">Receiver Name</label>
                                <input type="text" class="form-control" id="receiver_name" value="">

                            </div>
                            <div class="col-md-4">

                                <label for="">Mobile No</label>
                                <input type="text" class="form-control" id="receiver_phone" value="" maxlength="10">

                            </div>
                            <div class="col-md-4">

                                <label for="">Email id</label>
                                <input type="text" class="form-control" id="receiver_email" value="">

                            </div>
                        </div>

                        <br>
                        <div class="col-md-7">

                            <label for="">Receiver Address</label>
                            <br>
                            <span id="receiver_shipaddress"></span>

                        </div>
                        <div class="col-md-5" style="margin-top: 9%;">
                            <span id="nj"></span>
                            <input id="new" type="checkbox" name="cb" value="0">
                            <span style="color: orangered;">Generate Label.</span>
                            <input type="hidden" value="" id="b_id">
                            <input id="order_id" class="hidden" value="">
                        </div>

                        <div class="row" style="margin-top:3%;">
                            <button type="button" id="back" class="btn btn-danger btn-lg" style="margin-left:40%;" data-dismiss="">Back</button>
                            <button type="button" id="" class="btn btn-danger btn-lg proceed" data-dismiss="">Proceed</button>
                        </div>
                    </div>

                </div>
                <div id="booked" class="hidden" style="background-color: #f1f1f1;">
                    <div class="row" id="ecz" style="padding: 4%;">
                        <div class="col-md-6">
                            <p>Booking id : &nbsp;<span id="book_id"></span> </p>
                            <br><span id="track_id" style="font-size: 20px;"></span>
                            <br><span id="pdf" style="font-size: 20px;"></span>
                            <br><span id="cod_label" style="font-size: 20px;"></span>
                            <br>
                        </div>
                        <div class="col-md-6"></div>
                        <span id="nu"></span>
                        <span id="sp1"></span>
                        <span id="sp"></span>
                         <div class="col-md-12" id ="bsuccess" class="hidden" style="font-size: 39px;color: #4ca05b;margin-left: 26%;">Booking Successful !!!</div>
                    </div>
                   
                    <button type="button" id="gl" value="1" class="btn btn-danger btn-lg hidden" style="margin-left:40%;margin-top: 5%;" data-dismiss="">Generate Label</button>

                </div>
                <div id="details" class="hidden" style="height: 40%;background-color: #f1f1f1;">
                    <div class="col-md-7"><span id="det" style="font-size: 20px;"></span><br><span id='lbdown' style="font-size: 20px;"></span><br><br><span id="clbdown" style="font-size: 20px;"></span><span id='cod_id' value=''></span></div>
                    <div class="col-md-5"><span id="awb"></span><br>
                        <table class="table table-bordered" id="dnlk" style="width: 50%;">
                            <thead id="thead"></thead>
                            <tbody id="awb_no"></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function goBack() {
    history.go(-1);
}
</script>
</html>
