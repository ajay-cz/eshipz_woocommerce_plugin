<?php
function admin_bar_menu_modal_window( $wp_admin_bar )
{
	
	$wp_admin_bar->add_node( array(
		'id' => 'money',
		'title' => 'eCourierz Wallet Refill',
		'meta' => array(
			'class' => 'money-top'
		)
	));
    
    $key = get_option('x-api-token');
    $cd = get_option('partner_code');
    $part = explode("-", $key);
    
    $curl = curl_init();

    curl_setopt_array($curl, array(
    CURLOPT_URL => 'https://'.$cd.'/api/v1/customers/info/',
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "content-type: application/json",
    'x-api-token:'.$key.''
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);
//var_dump($response);
curl_close($curl);


    $result = json_decode($response, true);
    $mail = explode("@", $result['user_info']['primary_email']['0']);
    
	$j = 500;
    for($i = 500 ; $i <= 10000 ; $i = $i + 500){
	    // add "do stuff" link
        $wp_admin_bar->add_node( array(
            // id is required, but not important in this case
            'id' => 'money-'.$i,
            // set the parent to our root node
            'parent' => 'money',
            // this title is the <a> tag *content*
            'title' => 'Rs.'.$i,
            // notice the plugin page and thickbox iframe hint params
            'href' => 'https://www.instamojo.com/ecourierz/payments-for-ecourierz/?embed=form&intent=buy&amp;data_readonly=data_name&amp;data_readonly=data_email&amp;data_readonly=data_phone&amp;data_hidden=data_Field_89884&amp;data_hidden=data_Field_55953&amp;data_readonly=data_amount&amp;data_amount='.$i.'&amp;data_name='.$result['user_info']['primary_contact']['0'].'&amp;data_email='.$result['user_info']['primary_email']['0'].'&amp;data_Field_89884='.$part[0].'&amp;data_Field_55953=http%3A%2F%2F'.$cd.'.ecourierz.com%2Faccount%2Fwallet%2F&amp;data_phone='.$result['user_info']['primary_phone']['0'].'',

            'meta' => array(
                'target' => '_blank'
            )
        ));
    }
    	
    
}
add_action( 'admin_bar_menu', 'admin_bar_menu_modal_window', 999 );
?>