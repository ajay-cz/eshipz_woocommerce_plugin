eCourierz plugin - Woocommerce

*************************Description*******************************

=> This plugin is made for the woocommerce users to provide shipping solutions.


*************************Requirements******************************

=> Each product must have dimensions(length,width,height),weight and price.
=> Shipping address must contain pincode.

*************************Installation******************************

=> Upload zipped plugin to wordpress dashboard and activate it.
=> Go to Woocommerce->Settings->Ecourierz tab  and enter the x-api-token and partner-code whcih you will receive from ecourierz
   and save it.
=> Go to Woocommerce->Orders get rates and palce the booking for shipment.